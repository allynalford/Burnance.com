
const baseWithClass = "/<ul (class=.[^>{}]*(?:{+[^}]site-nav__dropdown text-left*}+[^>{}]*)*)>/s";

const baseWithOutClass = "/<ul (class=.[^>{}]*(?:{+[^}]site-nav__dropdown text-left*}+[^>{}]*)*)>/s"